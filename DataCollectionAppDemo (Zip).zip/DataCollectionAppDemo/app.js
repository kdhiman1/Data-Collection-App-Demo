const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const userRouter = require('./routes.js')
const flash = require('express-flash');
const session = require('express-session');
const path = require('path');
const jwt = require('jsonwebtoken');
const authRouter = require('./auth.js');
const SQLiteStore = require("connect-sqlite3")(session);
const passport = require("passport");
const createError = require("http-errors");
const cookieParser = require("cookie-parser");
const csurf = require("csurf");
const logger = require("morgan");

require("dotenv").config({
  path: path.join(__dirname, "../.env")
});

const app = express();

mongoose
 .connect("mongodb+srv://'Username':'Password'@seproddemo.mh3iz.mongodb.net/?retryWrites=true&w=majority")
 .then(() => {
  console.log('Connected to the Database successfully');
 });

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(express.urlencoded());
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
    secret: 'SEPROD',
    resave: false,
    saveUninitialized: true,
    store: new SQLiteStore({db: "sessions.db", dir: "./var/db"})
}));
app.use(passport.authenticate("session"));
app.use(flash());
app.use("/", userRouter);
app.use("/", authRouter);

app.listen(3000, function(){
  console.log("Server started on port 3000.");
});

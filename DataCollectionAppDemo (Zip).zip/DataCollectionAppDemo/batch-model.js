const mongoose = require('mongoose');

var batchDataSchema = new mongoose.Schema({
  id: String,
  productType: String,
  productionStage: String,
  newBatch: String,
  ffaPercentage: Number,
  peroxideValue: Number,
  temperature: Number,
  pressure: Number,
  dateToday: String,
  passFail: String,
  quantity: Number,
  tankNumber: Number
});

var batchDataModel = mongoose.model('batchData', batchDataSchema);

module.exports = mongoose.model("BatchData", batchDataSchema);

var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var batchDataModel = require('./batch-model.js');
var authRouter = require("./auth.js");
const passport = require("passport");

var db = mongoose.connection;

const secured = (req, res, next) => {
  if (req.username) {
    return next();
  }
  req.session.returnTo = req.originalUrl;
  res.redirect("/login");
};

router.get("/", function(req, res){
  res.render("home");
});

router.get("/login", function(req, res){
  res.render("login");
});

router.get("/dataCollection", function(req, res){
  res.render("dataCollection");
});

router.get("/CSFats", function(req, res){
  res.render("Fats/crudeStorage");
});

router.get("/CSOils", function(req, res){
  res.render("Oils/crudeStorage");
});

router.get("/trendDataSBOil", function(req, res){
  res.render("trendDataSBOil");
});

router.get("/trendDataPOil", function(req, res){
  res.render("trendDataPOil");
});

router.get("/trendDataPOlein", function(req, res){
  res.render("trendDataPOlein");
});

router.get("/trendDataPSterein", function(req, res){
  res.render("trendDataPSterein");
});

router.get("/productData", function(req, res, next){
  batchDataModel.find({}, function(err, batchParameters) {
    res.render('productData', {
        parameterList: batchParameters
    });
  });
});

router.post("/createNewBatch", function(req, res){
  var newBatch = new batchDataModel({
    id: req.body.bID,
    proudctType: req.body.type
  });

  db.collection('batchdatas').insertOne(newBatch, function(err, collection){
    if (err) throw err;
    console.log("Record inserted successfully");
  });

  return res.redirect("/dataCollection");

})

router.post("/enter_data", function(req, res){

  if (req.body.pFFA > 20) {
    var passFail = "Fail - % FFA over limit.";
  } else if (req.body.pV > 20) {
    var passFail = "Fail - Peroxide Value over limit."
  } else if (req.body.temp > 200) {
    var passFail = "Fail - Temperature over limit."
  } else if (req.body.press > 10) {
    var passFail = "Fail - Pressure over limit."
  } else {
    var passFail = "Pass";
  };

  var newBatchData = new batchDataModel({
    id: req.body.bID,
    productType: req.body.type,
    productionStage: req.body.stage,
    newBatch: Boolean(req.body.nBatch),
    ffaPercentage: req.body.pFFA,
    peroxideValue: req.body.pV,
    temperature: req.body.temp,
    pressure: req.body.press,
    dateToday: Date(),
    passFail: passFail,
    quantity: req.body.quan,
    tankNumber: req.body.tankNum
  });

  db.collection('batchdatas').insertOne(newBatchData, function(err, collection){
    if (err) throw err;
    console.log("Record inserted successfully");
  });
  return res.redirect("/productData");

});

module.exports = router;
